﻿const base = {
    url : "http://localhost:8080/springbootpymg7/"
}
export default base
